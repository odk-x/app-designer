window.odkTableSpecificDefinitions = {
  "_tokens": {
    "is_override": {
      "string_token": "is_override",
      "text": "Is Override",
      "_row_num": 2
    },
    "click_to_deliver": {
      "string_token": "click_to_deliver",
      "text": "Click To Deliver",
      "_row_num": 3
    },
    "entitlement_details": {
      "string_token": "entitlement_details",
      "text": "Entitlement Details",
      "_row_num": 4
    }
  }
}